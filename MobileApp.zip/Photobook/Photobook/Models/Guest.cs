﻿namespace Photobook.Models
{
    public class Guest
    {
        public string Username { get; set; }
        public string Pin { get; set; }
    }
}