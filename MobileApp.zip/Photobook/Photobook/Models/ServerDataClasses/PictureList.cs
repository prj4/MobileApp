﻿using System.Collections.Generic;

namespace Photobook.Models.ServerDataClasses
{
    public class RootObject
    {
        public List<string> PictureList { get; set; }
    }
}