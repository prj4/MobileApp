﻿namespace Photobook.Models
{
    public class ServerUser
    {
        public string Name { get; set; }
        public string Pin { get; set; }
    }
}