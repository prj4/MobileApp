﻿namespace Photobook.Models
{
    public class PhotoToServer
    {
        public byte[] Bytes { get; set; }
        public string Pin { get; set; }
    }
}