﻿using System.Collections.Generic;

namespace Photobook.Models.ServerDataClasses
{
    public class PictureListModel
    {
        public List<string> PictureList { get; set; }
    }
}