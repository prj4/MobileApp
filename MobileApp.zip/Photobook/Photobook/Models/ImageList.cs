﻿using System.Collections.Generic;

namespace Photobook.Models
{
    public class ImageList
    {
        public List<string> Photos = null;
    }
}