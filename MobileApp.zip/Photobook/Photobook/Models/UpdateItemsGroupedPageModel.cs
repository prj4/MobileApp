﻿namespace Photobook.Models
{
    public class UpdateItemsGroupedPageModel
    {
    }
}